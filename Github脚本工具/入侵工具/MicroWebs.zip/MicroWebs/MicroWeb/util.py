# -*- coding: utf-8 -*-
import random
import hashlib


def get_rand_str(length=32):
    string = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM12345567890"
    ret = []
    for x in [random.randint(0, len(string) - 1) for x in xrange(length)]:
        ret.append(string[x])
    return "".join(ret)


def md5(string=""):
    obj = hashlib.new("md5")
    obj.update(string)
    return obj.hexdigest()

def get_url_info(url):
    # return scheme host port path query
    if not url:
        return '', '', '', '', ''
    scheme = ""

    def getport(scheme):
        if scheme == "http":
            return '80'
        elif scheme == "https":
            return "443"
        else:
            return ""

    if url.startswith("file:///"):
        return 'file', url[8:], '', '', ''
    if url.count("://") > 0:
        tmp = url.split("://")[0]
        if tmp.isalpha():
            scheme = tmp
    hostname = ""
    port = ""
    path = ""
    query = ""
    if scheme:
        tmp = url.split("://", 1)[1]
        if tmp.count("/") > 0:
            host, querystring = tmp.split('/', 1)
            if host.count(":") > 0:
                hostname, port = host.split(":", 1)
            else:
                hostname = host
                port = getport(scheme)
            if querystring.count("?") > 0:
                path, query = querystring.split("?", 1)
            else:
                path = querystring
                query = ""
        else:
            if tmp.count(":") > 0:
                hostname, port = tmp.split(":", 1)
            else:
                hostname = tmp
                port = getport(scheme)
    else:
        port = "80"
        if url.count("/") > 0:
            host, querystring = url.split('/', 1)
            if host.count(":") > 0:
                hostname, port = host.split(":", 1)
            else:
                hostname = host
            if querystring.count("?") > 0:
                path, query = querystring.split("?", 1)
            else:
                path = querystring
                query = ""
        elif url.count(":") > 0:
            hostname, port = url.split(":", 1)
        else:
            hostname = url

    return scheme, hostname, int(port), "/" + path, query
