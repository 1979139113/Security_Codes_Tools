#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import chardet
from MicroWeb.models import Plugin
from MicroWeb.models import plugin_scanblock_mapper
import util



# 设置插件归属用户的uhash
uhash = "AFmNfGcSVczUUek5"
# 设置插件显示的作者
author = "admin"
# 设置插件来源页面
froms = "http://127.0.0.1"
# 设置插件是否私有
private = False

# 设置节点添加进去的模块
scan_block_name = "info_get"

if os.listdir("plugin"):
    print "[+++] File Exists In The Directory,Load Plugins"
else:
    print "[***] File Not Exists In The Directory"
count = 0
for site, site_list, file_list in os.walk("plugin"):
    # break
    for file_name in file_list:
        name = ''.join(file_name.split(".")[:-1])
        abs_filename = os.path.abspath(os.path.join('plugin', file_name))
        name = name.decode(chardet.detect(name).get("encoding")).encode("utf-8")
        abs_filename = abs_filename.decode(chardet.detect(abs_filename).get("encoding"))
        print "[+++] Load Filename:", name, " Absolute Path:", abs_filename
        phash = util.get_rand_str(16)
        while Plugin.objects.filter(phash=phash):
            phash = util.get_rand_str(16)
        try:
            Plugin.objects.create(uhash=uhash, author=author, froms=froms, title=name, private=private,
                                  body=open(abs_filename, "rb").read().decode('utf-8'), phash=phash)
            plugin_scanblock_mapper.objects.create(phash=phash, scan_fieldname=scan_block_name)
            os.remove(abs_filename)
            print "[---] Remove File:", abs_filename
            count += 1
        except Exception, e:
            print e
            pass

else:
    print "[***] Import:", count, "Plugin"
