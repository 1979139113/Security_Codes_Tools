# coding:utf-8
import __builtin__
from django.template import loader
import marshal

# 站点协议
SCHEME = "http"

# 站点地址端口
HOST = "127.0.0.1:80"

# 初始化节点代码位置
INIT_SITE = "init.py"

# 节点主要代码位置
NODE_SITE = "node.py"

# 后台管理登陆位置,支持正则表达式
# 注：此处有安全问题，所以给各位不是很了解django的用户提供一下方便
MANAGER_SITE = r"^admins/"

# task界面布局设置
Layout = True


# 编译节点代码文件
def compiles(site, context=None):
    if context:
        code = loader.get_template(site).render(context).__str__()
    else:
        code = open("./templates/" + site, "rU").read()
    f = open("./templates/" + site[:-2] + "bak.py", "wb")
    marshal.dump(__builtin__.compile(code, "./templates/" + site + "c", "exec"), f)
    f.close()
    return "./templates/" + site[:-2] + "bak.py"


print "==================Init Node Code=================="
print "Init File:", INIT_SITE, "\t Compile as:",
INIT_SITE = compiles(INIT_SITE, {"host": HOST, "scheme": SCHEME})
print INIT_SITE, "\nInit File:", NODE_SITE, "\t Compile as:",
NODE_SITE = compiles(NODE_SITE)
print NODE_SITE, "\n==================   Init Ok    =================="
