leakScan
========

在线漏洞扫描

任务列表:

![image](https://github.com/Skycrab/leakScan/blob/master/screenshot/task.png)


扫描任务创建:

![image](https://github.com/Skycrab/leakScan/blob/master/screenshot/create.jpg)

扫描基本信息:

![image](https://github.com/Skycrab/leakScan/blob/master/screenshot/detail.png)


目录结构:

![image](https://github.com/Skycrab/leakScan/blob/master/screenshot/tree.png)


漏洞详情:

![image](https://github.com/Skycrab/leakScan/blob/master/screenshot/vul.png)


详细可看使用说明
