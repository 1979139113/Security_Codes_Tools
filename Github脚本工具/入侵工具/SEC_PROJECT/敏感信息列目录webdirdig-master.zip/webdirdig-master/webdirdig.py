#!/usr/bin/env/python
#-*- coding:utf-8 -*-

__author__ = 'BlackYe.'


from lib.controller.controller import Controller
import sys

def main():
    Controller(sys.argv[1])


if __name__ == '__main__': main()