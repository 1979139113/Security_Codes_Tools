webdirdig
===================================  
web敏感目录\信息泄漏扫描脚本

Basic usage
===================================  

```
python webdirdig.py http://www.baidu.com
```