#!/usr/bin/env/python
#-*- coding:utf-8 -*-

__author__ = 'BlackYe.'

class RequestException(Exception):
    pass

class SkipTargetInterrupt(Exception):
    pass