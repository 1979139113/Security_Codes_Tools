#!/usr/bin/env/python
#-*- coding:utf-8 -*-

__author__ = 'BlackYe.'

import sys
sys.path.append("/data/project/webdirdig")